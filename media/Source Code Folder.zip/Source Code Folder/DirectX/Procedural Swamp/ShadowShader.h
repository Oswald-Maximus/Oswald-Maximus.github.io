#ifndef _SHADOW_SHADER_H
#define _SHADOW_DHADER_H

#include "../DXFramework/BaseShader.h"

using namespace std;
using namespace DirectX;

class ShadowShader : public BaseShader
{
public:
	ShadowShader(ID3D11Device* device, HWND hwnd);
	~ShadowShader();

	void setShaderParameters(ID3D11DeviceContext* deviceContext, const XMMATRIX &world, const XMMATRIX &view, const XMMATRIX &projection);

private:
	void initShader(WCHAR*, WCHAR*);
	void initShader(WCHAR* vs, WCHAR* gs, WCHAR* ps);

private:
	ID3D11Buffer* matrixBuffer;
};

#endif