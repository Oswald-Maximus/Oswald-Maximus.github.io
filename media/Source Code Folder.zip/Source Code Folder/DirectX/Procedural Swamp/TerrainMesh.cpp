//Space Colonisation source: algorithmicbotany.org/papers/colonization.egwnp2007.html

#include "TerrainMesh.h"

TerrainMesh::TerrainMesh(ID3D11Device* device, ID3D11DeviceContext* deviceContext)
{
	seed = time(NULL);
	initBuffers(device);
}

TerrainMesh::~TerrainMesh()
{
	BaseMesh::~BaseMesh();
}

void TerrainMesh::initBuffers(ID3D11Device* device)
{
	VertexType* vertices;
	unsigned long* indices;
	D3D11_BUFFER_DESC vertexBufferDesc, indexBufferDesc;
	D3D11_SUBRESOURCE_DATA vertexData, indexData;

	vertexCount = 65536;
	indexCount = 65536;

	vertices = new VertexType[vertexCount];
	indices = new unsigned long[indexCount];
	int blockCheck[64][64][16];

	int index = 0;
	for (int x = 0; x < 64; ++x)
	{
		for (int z = 0; z < 64; ++z)
		{
			bool isTree = false;
			for (int y = 0; y < 16; ++y)
			{
				vertices[index].position = XMFLOAT3(x, y, z);
				vertices[index].texture = XMFLOAT2(0, 0);
				if (y == 0)
				{
					float value = SwampValue();
					if (value > 0.9) //WATER
					{
						vertices[index].normal = XMFLOAT3(0, 0, 1);
						blockCheck[x][z][y] = 1;
					}
					else if (value < 0.51) //TREE
					{
						vertices[index].normal = XMFLOAT3(0, 1, 0);
						blockCheck[x][z][y] = 2;
						isTree = true;
					}
					else
					{
						vertices[index].normal = XMFLOAT3(1, 0, 0);
						blockCheck[x][z][y] = 3;
					}
				}
				else if (isTree)
				{
					vertices[index].normal = XMFLOAT3(0, 1, 0);
					vertices[index].texture.x += 32;
					blockCheck[x][z][y] = 2;
					isTree = false;
				}
				else
				{
					float value = SwampValue();
					if (value > 0.95) //ATTRACTION POINT
					{
						vertices[index].normal = XMFLOAT3(1, 1, 0);
						blockCheck[x][z][y] = 4;
					}
					else
					{
						vertices[index].normal = XMFLOAT3(0, 0, 0);
						blockCheck[x][z][y] = 0;
					}
				}
				
				++index;
			}
		}
	}
	for (int passes = 0; passes < 16; ++passes)
	{
		int i = 0;
		for (int x = 0; x < 64; ++x)
		{
			for (int z = 0; z < 64; ++z)
			{
				for (int y = 0; y < 16; ++y)
				{
					if (blockCheck[x][z][y] == 4) //ATTRACTION POINT
					{
						if (y - 1 >= 0)
						{
							if (blockCheck[x][z][y - 1] == 2)
							{
								vertices[i].normal = XMFLOAT3(0, 1, 0);
								vertices[i].texture.x = 16;
								blockCheck[x][z][y] = 2;
								goto FoundTree;
							}
							if (x - 1 >= 0)
							{
								if (blockCheck[x - 1][z][y - 1] == 2)
								{
									vertices[i].normal = XMFLOAT3(0, 1, 0);
									vertices[i].texture.x = 8;
									blockCheck[x][z][y] = 2;
									goto FoundTree;
								}
								if (z - 1 >= 0)
								{
									if (blockCheck[x-1][z - 1][y - 1] == 2)
									{
										vertices[i].normal = XMFLOAT3(0, 1, 0);
										vertices[i].texture.x = 64;
										blockCheck[x][z][y] = 2;
										goto FoundTree;
									}
								}
								if (z + 1 < 64)
								{
									if (blockCheck[x-1][z + 1][y - 1] == 2)
									{
										vertices[i].normal = XMFLOAT3(0, 1, 0);
										vertices[i].texture.x = 1;
										blockCheck[x][z][y] = 2;
										goto FoundTree;
									}
								}
							}
							if (x + 1 < 64)
							{
								if (blockCheck[x + 1][z][y - 1] == 2)
								{
									vertices[i].normal = XMFLOAT3(0, 1, 0);
									vertices[i].texture.x = 32;
									blockCheck[x][z][y] = 2;
									goto FoundTree;
								}
								if (z - 1 >= 0)
								{
									if (blockCheck[x+1][z - 1][y - 1] == 2)
									{
										vertices[i].normal = XMFLOAT3(0, 1, 0);
										vertices[i].texture.x = 256;
										blockCheck[x][z][y] = 2;
										goto FoundTree;
									}
								}
								if (z + 1 < 64)
								{
									if (blockCheck[x+1][z + 1][y - 1] == 2)
									{
										vertices[i].normal = XMFLOAT3(0, 1, 0);
										vertices[i].texture.x = 4;
										blockCheck[x][z][y] = 2;
										goto FoundTree;
									}
								}
							}
							if (z - 1 >= 0)
							{
								if (blockCheck[x][z - 1][y - 1] == 2)
								{
									vertices[i].normal = XMFLOAT3(0, 1, 0);
									vertices[i].texture.x = 128;
									blockCheck[x][z][y] = 2;
									goto FoundTree;
								}
							}
							if (z + 1 < 64)
							{
								if (blockCheck[x][z + 1][y - 1] == 2)
								{
									vertices[i].normal = XMFLOAT3(0, 1, 0);
									vertices[i].texture.x = 2;
									blockCheck[x][z][y] = 2;
									goto FoundTree;
								}
							}
						}
						if (x - 1 >= 0)
						{
							if (blockCheck[x - 1][z][y] == 2)
							{
								vertices[i].normal = XMFLOAT3(0, 1, 0);
								vertices[i].texture.x = 512;
								blockCheck[x][z][y] = 2;
								goto FoundTree;
							}
							if (z - 1 >= 0)
							{
								if (blockCheck[x - 1][z - 1][y] == 2)
								{
									vertices[i].normal = XMFLOAT3(0, 1, 0);
									vertices[i].texture.x = 1024;
									blockCheck[x][z][y] = 2;
									goto FoundTree;
								}
							}
							if (z + 1 < 64)
							{
								if (blockCheck[x - 1][z + 1][y] == 2)
								{
									vertices[i].normal = XMFLOAT3(0, 1, 0);
									vertices[i].texture.y = 4096;
									blockCheck[x][z][y] = 2;
									goto FoundTree;
								}
							}
						}
						if (x + 1 < 64)
						{
							if (blockCheck[x + 1][z][y] == 2)
							{
								vertices[i].normal = XMFLOAT3(0, 1, 0);
								vertices[i].texture.y = 512;
								blockCheck[x][z][y] = 2;
								goto FoundTree;
							}
							if (z - 1 >= 0)
							{
								if (blockCheck[x + 1][z - 1][y] == 2)
								{
									vertices[i].normal = XMFLOAT3(0, 1, 0);
									vertices[i].texture.x = 4096;
									blockCheck[x][z][y] = 2;
									goto FoundTree;
								}
							}
							if (z + 1 < 64)
							{
								if (blockCheck[x + 1][z + 1][y] == 2)
								{
									vertices[i].normal = XMFLOAT3(0, 1, 0);
									vertices[i].texture.y = 1024;
									blockCheck[x][z][y] = 2;
									goto FoundTree;
								}
							}
						}
						if (z - 1 >= 0)
						{
							if (blockCheck[x][z - 1][y] == 2)
							{
								vertices[i].normal = XMFLOAT3(0, 1, 0);
								vertices[i].texture.x = 2048;
								blockCheck[x][z][y] = 2;
								goto FoundTree;
							}
						}
						if (z + 1 < 64)
						{
							if (blockCheck[x][z + 1][y] == 2)
							{
								vertices[i].normal = XMFLOAT3(0, 1, 0);
								vertices[i].texture.y = 2048;
								blockCheck[x][z][y] = 2;
								goto FoundTree;
							}
						}
						if (y + 1 < 16)
						{
							if (blockCheck[x][z][y + 1] == 2)
							{
								vertices[i].normal = XMFLOAT3(0, 1, 0);
								vertices[i].texture.y = 16;
								blockCheck[x][z][y] = 2;
								goto FoundTree;
							}
							if (x - 1 >= 0)
							{
								if (blockCheck[x - 1][z][y + 1] == 2)
								{
									vertices[i].normal = XMFLOAT3(0, 1, 0);
									vertices[i].texture.y = 32;
									blockCheck[x][z][y] = 2;
									goto FoundTree;
								}
								if (z - 1 >= 0)
								{
									if (blockCheck[x - 1][z - 1][y + 1] == 2)
									{
										vertices[i].normal = XMFLOAT3(0, 1, 0);
										vertices[i].texture.y = 4;
										blockCheck[x][z][y] = 2;
										goto FoundTree;
									}
								}
								if (z + 1 < 64)
								{
									if (blockCheck[x - 1][z + 1][y + 1] == 2)
									{
										vertices[i].normal = XMFLOAT3(0, 1, 0);
										vertices[i].texture.y = 256;
										blockCheck[x][z][y] = 2;
										goto FoundTree;
									}
								}
							}
							if (x + 1 < 64)
							{
								if (blockCheck[x + 1][z][y + 1] == 2)
								{
									vertices[i].normal = XMFLOAT3(0, 1, 0);
									vertices[i].texture.y = 8;
									blockCheck[x][z][y] = 2;
									goto FoundTree;
								}
								if (z - 1 >= 0)
								{
									if (blockCheck[x + 1][z - 1][y + 1] == 2)
									{
										vertices[i].normal = XMFLOAT3(0, 1, 0);
										vertices[i].texture.y = 1;
										blockCheck[x][z][y] = 2;
										goto FoundTree;
									}
								}
								if (z + 1 < 64)
								{
									if (blockCheck[x + 1][z + 1][y + 1] == 2)
									{
										vertices[i].normal = XMFLOAT3(0, 1, 0);
										vertices[i].texture.y = 64;
										blockCheck[x][z][y] = 2;
										goto FoundTree;
									}
								}
							}
							if (z - 1 >= 0)
							{
								if (blockCheck[x][z - 1][y + 1] == 2)
								{
									vertices[i].normal = XMFLOAT3(0, 1, 0);
									vertices[i].texture.y = 2;
									blockCheck[x][z][y] = 2;
									goto FoundTree;
								}
							}
							if (z + 1 < 64)
							{
								if (blockCheck[x][z + 1][y + 1] == 2)
								{
									vertices[i].normal = XMFLOAT3(0, 1, 0);
									vertices[i].texture.y = 128;
									blockCheck[x][z][y] = 2;
									goto FoundTree;
								}
							}
						}

					}
					else if (blockCheck[x][z][y] == 3) //GROUND
					{
						int nearWater = 0;
						if (z + 1 < 64)
						{
							if (blockCheck[x][z + 1][y] == 1)
							{
								++nearWater;
							}
							if (x + 1 < 64)
							{
								if (blockCheck[x + 1][z+1][y] == 1)
								{
									++nearWater;
								}
							}
							if (x - 1 >= 0)
							{
								if (blockCheck[x - 1][z+1][y] == 1)
								{
									++nearWater;
								}
							}
						}
						if (z - 1 >= 0)
						{
							if (blockCheck[x][z + 1][y] == 1)
							{
								++nearWater;
							}
							if (x + 1 < 64)
							{
								if (blockCheck[x + 1][z-1][y] == 1)
								{
									++nearWater;
								}
							}
							if (x - 1 >= 0)
							{
								if (blockCheck[x - 1][z-1][y] == 1)
								{
									++nearWater;
								}
							}
						}
						if (x + 1 < 64)
						{
							if (blockCheck[x + 1][z][y] == 1)
							{
								++nearWater;
							}
						}
						if (x - 1 >= 0)
						{
							if (blockCheck[x - 1][z][y] == 1)
							{
								++nearWater;
							}
						}
						/*if (i + 16 < vertexCount)
						{
							if (blockCheck[i + 16] == 1 && (i + 16) % 64 != 0)
							{
								++nearWater;
							}
							if (i + 48 < vertexCount && (i - 16) % 64 != 63)
							{
								if (blockCheck[i + 48] == 1)
								{
									++nearWater;
								}
								if (i + 64 < vertexCount)
								{
									if (blockCheck[i + 64] == 1)
									{
										++nearWater;
									}
									if (i + 80 < vertexCount && (i + 16) % 64 != 0)
									{
										if (blockCheck[i + 80] == 1)
										{
											++nearWater;
										}
									}
								}
							}
						}
						if (i - 16 >= 0)
						{
							if (blockCheck[i - 16] == 1 && (i - 16) % 64 != 63)
							{
								++nearWater;
							}
							if (i - 48 >= 0)
							{
								if (blockCheck[i - 48] == 1 && (i + 16) % 64 != 0)
								{
									++nearWater;
								}
								if (i - 64 >= 0)
								{
									if (blockCheck[i - 64] == 1)
									{
										++nearWater;
									}
									if (i - 80 >= 0)
									{
										if (blockCheck[i - 80] == 1 && (i - 16) % 64 != 63)
										{
											++nearWater;
										}
									}
								}
							}
						}*/

						if (nearWater > 4)
						{
							vertices[i].normal = XMFLOAT3(0, 0, 1);
							blockCheck[x][z][y] = 1;
						}
					}
				FoundTree:;
					++i;
				}
			}
		}
		
	}


	for (int i = 0; i < indexCount; ++i)
	{
		indices[i] = i;
	}

	// Set up the description of the static vertex buffer.
	vertexBufferDesc.Usage = D3D11_USAGE_DEFAULT;
	vertexBufferDesc.ByteWidth = sizeof(VertexType)* vertexCount;
	vertexBufferDesc.BindFlags = D3D11_BIND_VERTEX_BUFFER;
	vertexBufferDesc.CPUAccessFlags = 0;
	vertexBufferDesc.MiscFlags = 0;
	vertexBufferDesc.StructureByteStride = 0;
	// Give the subresource structure a pointer to the vertex data.
	vertexData.pSysMem = vertices;
	vertexData.SysMemPitch = 0;
	vertexData.SysMemSlicePitch = 0;
	// Now create the vertex buffer.
	device->CreateBuffer(&vertexBufferDesc, &vertexData, &vertexBuffer);

	// Set up the description of the static index buffer.
	indexBufferDesc.Usage = D3D11_USAGE_DEFAULT;
	indexBufferDesc.ByteWidth = sizeof(unsigned long)* indexCount;
	indexBufferDesc.BindFlags = D3D11_BIND_INDEX_BUFFER;
	indexBufferDesc.CPUAccessFlags = 0;
	indexBufferDesc.MiscFlags = 0;
	indexBufferDesc.StructureByteStride = 0;
	// Give the subresource structure a pointer to the index data.
	indexData.pSysMem = indices;
	indexData.SysMemPitch = 0;
	indexData.SysMemSlicePitch = 0;
	// Create the index buffer.
	device->CreateBuffer(&indexBufferDesc, &indexData, &indexBuffer);

	// Release the arrays now that the vertex and index buffers have been created and loaded.
	delete[] vertices;
	vertices = 0;

	delete[] indices;
	indices = 0;
}

void TerrainMesh::sendData(ID3D11DeviceContext* deviceContext)
{
	unsigned int stride;
	unsigned int offset;

	// Set vertex buffer stride and offset.
	stride = sizeof(VertexType);
	offset = 0;

	deviceContext->IASetVertexBuffers(0, 1, &vertexBuffer, &stride, &offset);
	deviceContext->IASetIndexBuffer(indexBuffer, DXGI_FORMAT_R32_UINT, 0);
	deviceContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_POINTLIST);
}

float TerrainMesh::SwampValue()
{
	//64 bit Wang Hashing - Thomas Wang https://gist.github.com/badboy/6267743
	seed = (~seed) + (seed << 21);
	seed = seed ^ (seed >> 24);
	seed = (seed + (seed << 3)) + (seed << 8);
	seed = seed ^ (seed >> 14);
	seed = (seed + (seed << 2)) + (seed << 4);
	seed = seed ^ (seed >> 28);
	seed = seed + (seed << 31);
	//RandXorShift - George Marsaglia https://www.jstatsoft.org/article/view/v008i14
	seed ^= (seed << 16);
	seed ^= (seed >> 5);
	seed ^= (seed << 17);

	//convert to float between 0 and 1
	float timerf = seed * (1.0 / sizeof(time_t));

//dont let values outside the range escape
CheckRightRange:;
	if (timerf > 1)
	{
		timerf /= 2;
		goto CheckRightRange;
	}
	else if (timerf < 0)
	{
		timerf *= -1;
		goto CheckRightRange;
	}

	return timerf;
}