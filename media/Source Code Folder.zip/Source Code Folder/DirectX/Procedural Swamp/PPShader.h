#ifndef _PPSHADER_H
#define _PPSHADER_H

#include "..\DXFramework\BaseShader.h"

using namespace std;
using namespace DirectX;

class PPShader : public BaseShader
{
private:
	struct ScreenBufferType
	{
		float screenWidth;
		XMFLOAT3 padding;
	};
public:
	PPShader(ID3D11Device* device, HWND hwnd);
	~PPShader();

	void SetShaderParamenters(ID3D11DeviceContext* deviceContext, const XMMATRIX &world, const XMMATRIX &view, const XMMATRIX &projection, ID3D11ShaderResourceView* output, float screenWidth);
	void render(ID3D11DeviceContext* deviceContext, int vertexCount);

private:
	void initShader(WCHAR*, WCHAR*);

private:
	ID3D11Buffer* matrixBuffer;
	ID3D11SamplerState* samplerState;
	ID3D11Buffer* screenBuffer;
};

#endif