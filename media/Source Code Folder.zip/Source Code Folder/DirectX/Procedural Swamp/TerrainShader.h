#ifndef _TERRAIN_SHADER_H
#define _TERRAIN_SHADER_H

#include "..\DXFramework\BaseShader.h"
#include "..\DXFramework\Light.h"

using namespace std;
using namespace DirectX;

class TerrainShader : public BaseShader
{

private:
	struct LightCameraBufferType
	{
		XMFLOAT3 cameraPosition;
		XMMATRIX lightProjection;
		XMFLOAT4 lightAmbient;
		XMFLOAT4 lightDiffuse;
		XMFLOAT3 lightPosition;
		XMMATRIX lightView;
	};

public:
	TerrainShader(ID3D11Device* device, HWND hwnd);
	~TerrainShader();

	void SetShaderParamenters(ID3D11DeviceContext* deviceContext, const XMMATRIX &world, const XMMATRIX &view, const XMMATRIX &projection, ID3D11ShaderResourceView* shadowMap, Light* light, const XMMATRIX &lightProj, const XMMATRIX &lightView, XMFLOAT3 cameraPosition);
	void render(ID3D11DeviceContext* deviceContext, int vertexCount);

private:
	void initShader(WCHAR*, WCHAR*);
	void initShader(WCHAR* vs, WCHAR* gs, WCHAR* ps);

private:
	ID3D11Buffer* matrixBuffer;
	ID3D11SamplerState* clampSampState;
	ID3D11Buffer* lightCameraBuffer;
};

#endif // !_TERRAIN_SHADER_H
