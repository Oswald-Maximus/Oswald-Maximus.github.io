#ifndef _TERRAIN_MESH_H
#define _TERRAIN_MESH_H

#include "../DXFramework/BaseMesh.h"
#include <time.h>

using namespace DirectX;

class TerrainMesh : public BaseMesh
{
public:
	TerrainMesh(ID3D11Device* device, ID3D11DeviceContext* deviceContext);
	~TerrainMesh();

	void sendData(ID3D11DeviceContext*);

protected:
	void initBuffers(ID3D11Device* device);
	float SwampValue();
	time_t seed;
};
#endif // !_TERRAIN_MESH_H
