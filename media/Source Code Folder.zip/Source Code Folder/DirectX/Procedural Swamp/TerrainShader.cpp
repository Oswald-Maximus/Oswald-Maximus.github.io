#include "TerrainShader.h"

TerrainShader::TerrainShader(ID3D11Device* device, HWND hwnd) : BaseShader(device, hwnd)
{
	initShader(L"Terrain_vs.cso", L"Terrain_gs.cso", L"Terrain_ps.cso");
}

TerrainShader::~TerrainShader()
{
	if (matrixBuffer)
	{
		matrixBuffer->Release();
		matrixBuffer = 0;
	}
	BaseShader::~BaseShader();
}

void TerrainShader::initShader(WCHAR* vs, WCHAR* ps)
{
	loadVertexShader(vs);
	loadPixelShader(ps);

	D3D11_BUFFER_DESC matrixBufferDesc;
	D3D11_BUFFER_DESC lightCameraBufferDesc;
	D3D11_SAMPLER_DESC samplerDesc;

	//matrix buffer description
	matrixBufferDesc.Usage = D3D11_USAGE_DYNAMIC;
	matrixBufferDesc.ByteWidth = sizeof(MatrixBufferType);
	matrixBufferDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
	matrixBufferDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
	matrixBufferDesc.MiscFlags = 0;
	matrixBufferDesc.StructureByteStride = 0;

	renderer->CreateBuffer(&matrixBufferDesc, NULL, &matrixBuffer);

	//Light and Camera buffer Description
	lightCameraBufferDesc.Usage = D3D11_USAGE_DYNAMIC;
	lightCameraBufferDesc.ByteWidth = sizeof(LightCameraBufferType);
	lightCameraBufferDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
	lightCameraBufferDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
	lightCameraBufferDesc.MiscFlags = 0;
	lightCameraBufferDesc.StructureByteStride = 0;

	renderer->CreateBuffer(&lightCameraBufferDesc, NULL, &lightCameraBuffer);

	//sampler description
	samplerDesc.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
	samplerDesc.AddressU = D3D11_TEXTURE_ADDRESS_CLAMP;
	samplerDesc.AddressV = D3D11_TEXTURE_ADDRESS_CLAMP;
	samplerDesc.AddressW = D3D11_TEXTURE_ADDRESS_CLAMP;
	samplerDesc.MipLODBias = 0.0f;
	samplerDesc.MaxAnisotropy = 1;
	samplerDesc.ComparisonFunc = D3D11_COMPARISON_ALWAYS;
	samplerDesc.BorderColor[0] = 0;
	samplerDesc.BorderColor[1] = 0;
	samplerDesc.BorderColor[2] = 0;
	samplerDesc.BorderColor[3] = 0;
	samplerDesc.MinLOD = 0;
	samplerDesc.MaxLOD = D3D11_FLOAT32_MAX;

	// Create the texture sampler state.
	renderer->CreateSamplerState(&samplerDesc, &clampSampState);
}

void TerrainShader::initShader(WCHAR* vs, WCHAR* gs, WCHAR* ps)
{
	loadGeometryShader(gs);
	initShader(vs, ps);
}

void TerrainShader::SetShaderParamenters(ID3D11DeviceContext* deviceContext, const XMMATRIX &world, const XMMATRIX &view, const XMMATRIX &projection, ID3D11ShaderResourceView* shadowMap, Light* light, const XMMATRIX &lightProj, const XMMATRIX &lightView, XMFLOAT3 cameraPosition)
{
	HRESULT result;
	D3D11_MAPPED_SUBRESOURCE mappedResource;
	MatrixBufferType* dataPtr;
	LightCameraBufferType* lightPtr;
	unsigned int bufferNumber;
	XMMATRIX tWorld, tView, tProj, tlightProj, tlightView;

	tWorld = XMMatrixTranspose(world);
	tView = XMMatrixTranspose(view);
	tProj = XMMatrixTranspose(projection);
	//matrix buffer
	result = deviceContext->Map(matrixBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &mappedResource);

	dataPtr = (MatrixBufferType*)mappedResource.pData;

	dataPtr->world = tWorld;
	dataPtr->view = tView;
	dataPtr->projection = tProj;

	deviceContext->Unmap(matrixBuffer, 0);

	bufferNumber = 0;

	deviceContext->GSSetConstantBuffers(bufferNumber, 1, &matrixBuffer);

	tlightProj = XMMatrixTranspose(lightProj);
	tlightView = XMMatrixTranspose(lightView);

	/*set up light and camera buffer*/
	result = deviceContext->Map(lightCameraBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &mappedResource);

	lightPtr = (LightCameraBufferType*)mappedResource.pData;
	lightPtr->cameraPosition = cameraPosition;
	lightPtr->lightAmbient = light->getAmbientColour();
	lightPtr->lightDiffuse = light->getDiffuseColour();
	lightPtr->lightPosition = light->getPosition();
	lightPtr->lightProjection = tlightProj;
	lightPtr->lightView = tlightView;
	deviceContext->Unmap(lightCameraBuffer, 0);
	bufferNumber = 1;
	deviceContext->PSSetConstantBuffers(bufferNumber, 1, &lightCameraBuffer);

	deviceContext->PSSetShaderResources(0, 1, &shadowMap);
}

void TerrainShader::render(ID3D11DeviceContext* deviceContext, int indexCount)
{
	// Set the sampler state in the pixel shader.
	deviceContext->PSSetSamplers(0, 1, &clampSampState);

	// Base render function.
	BaseShader::render(deviceContext, indexCount);
}