#ifndef _PUZZLE_SHADER_H
#define _PUZZLE_SHADER_H

#include "../DXFramework/BaseShader.h"
#include "../DXFramework/Light.h"

using namespace std;
using namespace DirectX;

class PuzzleShader : public BaseShader
{
	
private:
	struct RotationBufferType
	{
		XMFLOAT4 rotation;
	};

	struct LightCameraBufferType
	{
		XMFLOAT3 cameraPosition;
		float lightSpecPower;
		XMMATRIX lightProjection;
		XMFLOAT4 lightAmbient;
		XMFLOAT4 lightDiffuse;
		XMFLOAT3 lightPosition;
		XMMATRIX lightView;
		XMFLOAT4 lightSpecColour;
	};

public:
	PuzzleShader(ID3D11Device* device, HWND hwnd);
	~PuzzleShader();

	void setShaderParameters(ID3D11DeviceContext* deviceContext, const XMMATRIX &world, const XMMATRIX &view, const XMMATRIX &projection, const XMFLOAT4 rotation, ID3D11ShaderResourceView* texture, XMFLOAT3 cameraPosition, Light* light, const XMMATRIX &lightProj, const XMMATRIX &lightView, ID3D11ShaderResourceView* shadowMap);
	void render(ID3D11DeviceContext* deviceContext, int vertexCount);

private:
	void initShader(WCHAR*, WCHAR*);
	void initShader(WCHAR* vs, WCHAR* gs, WCHAR* ps);

private:
	ID3D11Buffer* matrixBuffer;
	ID3D11Buffer* rotationBuffer;
	ID3D11Buffer* lightCameraBuffer;
	ID3D11SamplerState* sampleState;
	ID3D11SamplerState* clampSampState;

};
#endif
