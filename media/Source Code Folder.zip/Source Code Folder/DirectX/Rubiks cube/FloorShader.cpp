#include "FloorShader.h"

FloorShader::FloorShader(ID3D11Device* device, HWND hwnd) : BaseShader(device, hwnd)
{
	initShader(L"Floor_vs.cso", L"Floor_hs.cso", L"Floor_ds.cso", L"Floor_ps.cso");
}

FloorShader::~FloorShader()
{
	if (matrixBuffer)
	{
		matrixBuffer->Release();
		matrixBuffer = 0;
	}
	if (lightCameraBuffer)
	{
		lightCameraBuffer->Release();
		lightCameraBuffer = 0;
	}
	BaseShader::~BaseShader();
}

void FloorShader::initShader(WCHAR* vsFilename, WCHAR* psFilename)
{
	loadVertexShader(vsFilename);
	loadPixelShader(psFilename);

	D3D11_BUFFER_DESC matrixBufferDesc;
	D3D11_BUFFER_DESC lightCameraBufferDesc;
	D3D11_SAMPLER_DESC samplerDesc;

	//matrix buffer description
	matrixBufferDesc.Usage = D3D11_USAGE_DYNAMIC;
	matrixBufferDesc.ByteWidth = sizeof(MatrixBufferType);
	matrixBufferDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
	matrixBufferDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
	matrixBufferDesc.MiscFlags = 0;
	matrixBufferDesc.StructureByteStride = 0;

	renderer->CreateBuffer(&matrixBufferDesc, NULL, &matrixBuffer);

	//sampler description
	samplerDesc.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
	samplerDesc.AddressU = D3D11_TEXTURE_ADDRESS_CLAMP;
	samplerDesc.AddressV = D3D11_TEXTURE_ADDRESS_CLAMP;
	samplerDesc.AddressW = D3D11_TEXTURE_ADDRESS_CLAMP;
	samplerDesc.MipLODBias = 0.0f;
	samplerDesc.MaxAnisotropy = 1;
	samplerDesc.ComparisonFunc = D3D11_COMPARISON_ALWAYS;
	samplerDesc.BorderColor[0] = 0;
	samplerDesc.BorderColor[1] = 0;
	samplerDesc.BorderColor[2] = 0;
	samplerDesc.BorderColor[3] = 0;
	samplerDesc.MinLOD = 0;
	samplerDesc.MaxLOD = D3D11_FLOAT32_MAX;

	//Light and Camera buffer Description
	lightCameraBufferDesc.Usage = D3D11_USAGE_DYNAMIC;
	lightCameraBufferDesc.ByteWidth = sizeof(LightCameraBufferType);
	lightCameraBufferDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
	lightCameraBufferDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
	lightCameraBufferDesc.MiscFlags = 0;
	lightCameraBufferDesc.StructureByteStride = 0;

	renderer->CreateBuffer(&lightCameraBufferDesc, NULL, &lightCameraBuffer);

	// Create the texture sampler state.
	renderer->CreateSamplerState(&samplerDesc, &sampleState);
}

void FloorShader::initShader(WCHAR* vs, WCHAR* hs, WCHAR* ds, WCHAR* ps)
{
	//overload initShader, loading the hull and domain shaders then continuing as usual
	loadHullShader(hs);
	loadDomainShader(ds);
	initShader(vs, ps);
}

void FloorShader::setShaderParameters(ID3D11DeviceContext* deviceContext, const XMMATRIX &world, const XMMATRIX &view, const XMMATRIX &projection, ID3D11ShaderResourceView* shadowMap, Light* light, const XMMATRIX &lightProj, const XMMATRIX &lightView, XMFLOAT3 cameraPosition)
{
	HRESULT result;
	D3D11_MAPPED_SUBRESOURCE mappedResource;
	MatrixBufferType* dataPtr;
	LightCameraBufferType* lightPtr;
	unsigned int bufferNumber;
	XMMATRIX tworld, tview, tproj, tlightProj, tlightView;

	// Transpose the matrices to prepare them for the shader.
	tworld = XMMatrixTranspose(world);
	tview = XMMatrixTranspose(view);
	tproj = XMMatrixTranspose(projection);

	// Lock the constant buffer so it can be written to.
	result = deviceContext->Map(matrixBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &mappedResource);

	// Get a pointer to the data in the constant buffer.
	dataPtr = (MatrixBufferType*)mappedResource.pData;

	// Copy the matrices into the constant buffer.
	dataPtr->world = tworld;
	dataPtr->view = tview;
	dataPtr->projection = tproj;

	// Unlock the constant buffer.
	deviceContext->Unmap(matrixBuffer, 0);

	// Set the position of the constant buffer in the vertex shader.
	bufferNumber = 0;

	// Now set the constant buffer in the vertex shader with the updated values.
	deviceContext->DSSetConstantBuffers(bufferNumber, 1, &matrixBuffer);

	tlightProj = XMMatrixTranspose(lightProj);
	tlightView = XMMatrixTranspose(lightView);

	/*set up light and camera buffer*/
	result = deviceContext->Map(lightCameraBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &mappedResource);
	if (!result) goto NoClueMate;
	lightPtr = (LightCameraBufferType*)mappedResource.pData;
	lightPtr->cameraPosition = cameraPosition;
	lightPtr->lightAmbient = light->getAmbientColour();
	lightPtr->lightDiffuse = light->getDiffuseColour();
	lightPtr->lightPosition = light->getPosition();
	lightPtr->lightProjection = tlightProj;
	lightPtr->lightView = tlightView;
	lightPtr->lightSpecColour = light->getSpecularColour();
	lightPtr->lightSpecPower = light->getSpecularPower();
	deviceContext->Unmap(lightCameraBuffer, 0);
	bufferNumber = 2;
	deviceContext->PSSetConstantBuffers(bufferNumber, 1, &lightCameraBuffer);
	NoClueMate:
	//set up shadow map texture
	deviceContext->PSSetShaderResources(0, 1, &shadowMap);

}

void FloorShader::render(ID3D11DeviceContext* deviceContext, int indexCount)
{
	// Set the sampler state in the pixel shader.
	deviceContext->PSSetSamplers(0, 1, &sampleState);

	// Base render function.
	BaseShader::render(deviceContext, indexCount);
}