#ifndef _FLOOR_SHADOW_SHADER_H
#define _FLOOR_SHADOW_SHADER_H

#include "../DXFramework/BaseShader.h"

using namespace std;
using namespace DirectX;

class FloorShadowShader : public BaseShader
{

private:
	

public:
	FloorShadowShader(ID3D11Device* device, HWND hwnd);
	~FloorShadowShader();

	void setShaderParameters(ID3D11DeviceContext* deviceContext, const XMMATRIX &world, const XMMATRIX &view, const XMMATRIX &projection);

private:
	void initShader(WCHAR*, WCHAR*);
	void initShader(WCHAR* vs, WCHAR* hs, WCHAR* ds, WCHAR* ps);

private:
	ID3D11Buffer* matrixBuffer;

};

#endif