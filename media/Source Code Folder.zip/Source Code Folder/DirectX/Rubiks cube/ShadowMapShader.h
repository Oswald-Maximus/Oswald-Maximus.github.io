#ifndef _SHADOW_MAP_SHADER_H
#define _SHADOW_MAP_SHADER_H

#include "../DXFramework/BaseShader.h"

using namespace std;
using namespace DirectX;

class ShadowMapShader : public BaseShader
{

private:
	struct RotationBufferType
	{
		XMFLOAT4 rotation;
	};

public:
	ShadowMapShader(ID3D11Device* device, HWND hwnd);
	~ShadowMapShader();

	void setShaderParameters(ID3D11DeviceContext* deviceContext, const XMMATRIX &world, const XMMATRIX &view, const XMMATRIX &projection, const XMFLOAT4 rotation);

private:
	void initShader(WCHAR*, WCHAR*);
	void initShader(WCHAR* vs, WCHAR* gs, WCHAR* ps);

private:
	ID3D11Buffer* matrixBuffer;
	ID3D11Buffer* rotationBuffer;
};

#endif