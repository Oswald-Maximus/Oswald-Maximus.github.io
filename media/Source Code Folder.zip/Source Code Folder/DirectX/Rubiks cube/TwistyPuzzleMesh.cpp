#include "TwistyPuzzleMesh.h"

TwistyPuzzleMesh::TwistyPuzzleMesh(ID3D11Device* device, ID3D11DeviceContext* deviceContext)
{
	initBuffers(device);
}

TwistyPuzzleMesh::~TwistyPuzzleMesh()
{
	BaseMesh::~BaseMesh();
}

void TwistyPuzzleMesh::initBuffers(ID3D11Device* device)
{
	VertexType* vertices;
	unsigned long* indices;
	D3D11_BUFFER_DESC vertexBufferDesc, indexBufferDesc;
	D3D11_SUBRESOURCE_DATA vertexData, indexData;

	vertexCount = 26;
	indexCount = 26;


	vertices = new VertexType[vertexCount];
	indices = new unsigned long[indexCount];

	// Load the vertex array with data.
	// 3x3x3 cube with no centre
	
	vertices[0].position = XMFLOAT3(-1.0f, 1.0f, 1.0f);
	vertices[0].texture = XMFLOAT2(0.0f, 1.0f);
	vertices[0].normal = XMFLOAT3(0.0f, 0.0f, -1.0f);

	vertices[1].position = XMFLOAT3(0.0f, 1.0f, 1.0f);
	vertices[1].texture = XMFLOAT2(0.0f, 1.0f);
	vertices[1].normal = XMFLOAT3(0.0f, 0.0f, -1.0f);

	vertices[2].position = XMFLOAT3(1.0f, 1.0f, 1.0f);
	vertices[2].texture = XMFLOAT2(0.0f, 1.0f);
	vertices[2].normal = XMFLOAT3(0.0f, 0.0f, -1.0f);

	vertices[3].position = XMFLOAT3(-1.0f, 1.0f, 0.0f);
	vertices[3].texture = XMFLOAT2(0.0f, 1.0f);
	vertices[3].normal = XMFLOAT3(0.0f, 0.0f, -1.0f);

	vertices[4].position = XMFLOAT3(0.0f, 1.0f, 0.0f);
	vertices[4].texture = XMFLOAT2(0.0f, 1.0f);
	vertices[4].normal = XMFLOAT3(0.0f, 0.0f, -1.0f);

	vertices[5].position = XMFLOAT3(1.0f, 1.0f, 0.0f);
	vertices[5].texture = XMFLOAT2(0.0f, 1.0f);
	vertices[5].normal = XMFLOAT3(0.0f, 0.0f, -1.0f);

	vertices[6].position = XMFLOAT3(-1.0f, 1.0f, -1.0f);
	vertices[6].texture = XMFLOAT2(0.0f, 1.0f);
	vertices[6].normal = XMFLOAT3(0.0f, 0.0f, -1.0f);

	vertices[7].position = XMFLOAT3(0.0f, 1.0f, -1.0f);
	vertices[7].texture = XMFLOAT2(0.0f, 1.0f);
	vertices[7].normal = XMFLOAT3(0.0f, 0.0f, -1.0f);

	vertices[8].position = XMFLOAT3(1.0f, 1.0f, -1.0f);
	vertices[8].texture = XMFLOAT2(0.0f, 1.0f);
	vertices[8].normal = XMFLOAT3(0.0f, 0.0f, -1.0f);

	vertices[9].position = XMFLOAT3(-1.0f, 0.0f, 1.0f);
	vertices[9].texture = XMFLOAT2(0.0f, 1.0f);
	vertices[9].normal = XMFLOAT3(0.0f, 0.0f, -1.0f);

	vertices[10].position = XMFLOAT3(0.0f, 0.0f, 1.0f);
	vertices[10].texture = XMFLOAT2(0.0f, 1.0f);
	vertices[10].normal = XMFLOAT3(0.0f, 0.0f, -1.0f);

	vertices[11].position = XMFLOAT3(1.0f, 0.0f, 1.0f);
	vertices[11].texture = XMFLOAT2(0.0f, 1.0f);
	vertices[11].normal = XMFLOAT3(0.0f, 0.0f, -1.0f);

	vertices[12].position = XMFLOAT3(-1.0f, 0.0f, 0.0f);
	vertices[12].texture = XMFLOAT2(0.0f, 1.0f);
	vertices[12].normal = XMFLOAT3(0.0f, 0.0f, -1.0f);

	vertices[13].position = XMFLOAT3(1.0f, 0.0f, 0.0f);
	vertices[13].texture = XMFLOAT2(0.0f, 1.0f);
	vertices[13].normal = XMFLOAT3(0.0f, 0.0f, -1.0f);

	vertices[14].position = XMFLOAT3(-1.0f, 0.0f, -1.0f);
	vertices[14].texture = XMFLOAT2(0.0f, 1.0f);
	vertices[14].normal = XMFLOAT3(0.0f, 0.0f, -1.0f);

	vertices[15].position = XMFLOAT3(0.0f, 0.0f, -1.0f);
	vertices[15].texture = XMFLOAT2(0.0f, 1.0f);
	vertices[15].normal = XMFLOAT3(0.0f, 0.0f, -1.0f);

	vertices[16].position = XMFLOAT3(1.0f, 0.0f, -1.0f);
	vertices[16].texture = XMFLOAT2(0.0f, 1.0f);
	vertices[16].normal = XMFLOAT3(0.0f, 0.0f, -1.0f);

	vertices[17].position = XMFLOAT3(-1.0f, -1.0f, 1.0f);
	vertices[17].texture = XMFLOAT2(0.0f, 1.0f);
	vertices[17].normal = XMFLOAT3(0.0f, 0.0f, -1.0f);

	vertices[18].position = XMFLOAT3(0.0f, -1.0f, 1.0f);
	vertices[18].texture = XMFLOAT2(0.0f, 1.0f);
	vertices[18].normal = XMFLOAT3(0.0f, 0.0f, -1.0f);

	vertices[19].position = XMFLOAT3(1.0f, -1.0f, 1.0f);
	vertices[19].texture = XMFLOAT2(0.0f, 1.0f);
	vertices[19].normal = XMFLOAT3(0.0f, 0.0f, -1.0f);

	vertices[20].position = XMFLOAT3(-1.0f, -1.0f, 0.0f);
	vertices[20].texture = XMFLOAT2(0.0f, 1.0f);
	vertices[20].normal = XMFLOAT3(0.0f, 0.0f, -1.0f);

	vertices[21].position = XMFLOAT3(0.0f, -1.0f, 0.0f);
	vertices[21].texture = XMFLOAT2(0.0f, 1.0f);
	vertices[21].normal = XMFLOAT3(0.0f, 0.0f, -1.0f);

	vertices[22].position = XMFLOAT3(1.0f, -1.0f, 0.0f);
	vertices[22].texture = XMFLOAT2(0.0f, 1.0f);
	vertices[22].normal = XMFLOAT3(0.0f, 0.0f, -1.0f);

	vertices[23].position = XMFLOAT3(-1.0f, -1.0f, -1.0f);
	vertices[23].texture = XMFLOAT2(0.0f, 1.0f);
	vertices[23].normal = XMFLOAT3(0.0f, 0.0f, -1.0f);

	vertices[24].position = XMFLOAT3(0.0f, -1.0f, -1.0f);
	vertices[24].texture = XMFLOAT2(0.0f, 1.0f);
	vertices[24].normal = XMFLOAT3(0.0f, 0.0f, -1.0f);

	vertices[25].position = XMFLOAT3(1.0f, -1.0f, -1.0f);
	vertices[25].texture = XMFLOAT2(0.0f, 1.0f);
	vertices[25].normal = XMFLOAT3(0.0f, 0.0f, -1.0f);

	// Load the index array with data.
	indices[0] = 0;
	indices[1] = 1;
	indices[2] = 2;
	indices[3] = 3;
	indices[4] = 4;
	indices[5] = 5;
	indices[6] = 6;
	indices[7] = 7;
	indices[8] = 8;
	indices[9] = 9;
	indices[10] = 10;
	indices[11] = 11;
	indices[12] = 12;
	indices[13] = 13;
	indices[14] = 14;
	indices[15] = 15;
	indices[16] = 16;
	indices[17] = 17;
	indices[18] = 18;
	indices[19] = 19;
	indices[20] = 20;
	indices[21] = 21;
	indices[22] = 22;
	indices[23] = 23;
	indices[24] = 24;
	indices[25] = 25;


	// Set up the description of the static vertex buffer.
	vertexBufferDesc.Usage = D3D11_USAGE_DEFAULT;
	vertexBufferDesc.ByteWidth = sizeof(VertexType)* vertexCount;
	vertexBufferDesc.BindFlags = D3D11_BIND_VERTEX_BUFFER;
	vertexBufferDesc.CPUAccessFlags = 0;
	vertexBufferDesc.MiscFlags = 0;
	vertexBufferDesc.StructureByteStride = 0;
	// Give the subresource structure a pointer to the vertex data.
	vertexData.pSysMem = vertices;
	vertexData.SysMemPitch = 0;
	vertexData.SysMemSlicePitch = 0;
	// Now create the vertex buffer.
	device->CreateBuffer(&vertexBufferDesc, &vertexData, &vertexBuffer);

	// Set up the description of the static index buffer.
	indexBufferDesc.Usage = D3D11_USAGE_DEFAULT;
	indexBufferDesc.ByteWidth = sizeof(unsigned long)* indexCount;
	indexBufferDesc.BindFlags = D3D11_BIND_INDEX_BUFFER;
	indexBufferDesc.CPUAccessFlags = 0;
	indexBufferDesc.MiscFlags = 0;
	indexBufferDesc.StructureByteStride = 0;
	// Give the subresource structure a pointer to the index data.
	indexData.pSysMem = indices;
	indexData.SysMemPitch = 0;
	indexData.SysMemSlicePitch = 0;
	// Create the index buffer.
	device->CreateBuffer(&indexBufferDesc, &indexData, &indexBuffer);

	// Release the arrays now that the vertex and index buffers have been created and loaded.
	delete[] vertices;
	vertices = 0;

	delete[] indices;
	indices = 0;
}

// Override sendData()
// Change in primitive topology (pointlist instead of trianglelist) for geometry shader use.
void TwistyPuzzleMesh::sendData(ID3D11DeviceContext* deviceContext)
{
	unsigned int stride;
	unsigned int offset;

	// Set vertex buffer stride and offset.
	stride = sizeof(VertexType);
	offset = 0;

	deviceContext->IASetVertexBuffers(0, 1, &vertexBuffer, &stride, &offset);
	deviceContext->IASetIndexBuffer(indexBuffer, DXGI_FORMAT_R32_UINT, 0);
	deviceContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_POINTLIST);
}