#include "PuzzleShader.h"

PuzzleShader::PuzzleShader(ID3D11Device* device, HWND hwnd) : BaseShader(device, hwnd)
{
	initShader(L"Puzzle_vs.cso", L"Puzzle_gs.cso", L"Puzzle_ps.cso");
}

PuzzleShader::~PuzzleShader()
{
	if (matrixBuffer)
	{
		matrixBuffer->Release();
		matrixBuffer = 0;
	}
	if (rotationBuffer)
	{
		rotationBuffer->Release();
		rotationBuffer = 0;
	}
	if (lightCameraBuffer)
	{
		lightCameraBuffer->Release();
		lightCameraBuffer = 0;
	}
	BaseShader::~BaseShader();
}

void PuzzleShader::initShader(WCHAR* vsFilename, WCHAR* psFilename)
{
	loadVertexShader(vsFilename);
	loadPixelShader(psFilename);

	D3D11_BUFFER_DESC matrixBufferDesc;
	D3D11_BUFFER_DESC rotationBufferDesc;
	D3D11_BUFFER_DESC lightCameraBufferDesc;
	D3D11_SAMPLER_DESC samplerDesc;

	//matrix buffer description
	matrixBufferDesc.Usage = D3D11_USAGE_DYNAMIC;
	matrixBufferDesc.ByteWidth = sizeof(MatrixBufferType);
	matrixBufferDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
	matrixBufferDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
	matrixBufferDesc.MiscFlags = 0;
	matrixBufferDesc.StructureByteStride = 0;

	renderer->CreateBuffer(&matrixBufferDesc, NULL, &matrixBuffer);

	//rotation buffer description
	rotationBufferDesc.Usage = D3D11_USAGE_DYNAMIC;
	rotationBufferDesc.ByteWidth = sizeof(RotationBufferType);
	rotationBufferDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
	rotationBufferDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
	rotationBufferDesc.MiscFlags = 0;
	rotationBufferDesc.StructureByteStride = 0;

	renderer->CreateBuffer(&rotationBufferDesc, NULL, &rotationBuffer);

	//Light and Camera buffer Description
	lightCameraBufferDesc.Usage = D3D11_USAGE_DYNAMIC;
	lightCameraBufferDesc.ByteWidth = sizeof(LightCameraBufferType);
	lightCameraBufferDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
	lightCameraBufferDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
	lightCameraBufferDesc.MiscFlags = 0;
	lightCameraBufferDesc.StructureByteStride = 0;

	renderer->CreateBuffer(&lightCameraBufferDesc, NULL, &lightCameraBuffer);

	//sampler description
	samplerDesc.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
	samplerDesc.AddressU = D3D11_TEXTURE_ADDRESS_MIRROR;
	samplerDesc.AddressV = D3D11_TEXTURE_ADDRESS_MIRROR;
	samplerDesc.AddressW = D3D11_TEXTURE_ADDRESS_MIRROR;
	samplerDesc.MipLODBias = 0.0f;
	samplerDesc.MaxAnisotropy = 1;
	samplerDesc.ComparisonFunc = D3D11_COMPARISON_ALWAYS;
	samplerDesc.BorderColor[0] = 0;
	samplerDesc.BorderColor[1] = 0;
	samplerDesc.BorderColor[2] = 0;
	samplerDesc.BorderColor[3] = 0;
	samplerDesc.MinLOD = 0;
	samplerDesc.MaxLOD = D3D11_FLOAT32_MAX;

	// Create the texture sampler state.
	renderer->CreateSamplerState(&samplerDesc, &sampleState);

	//clamped sampler changes to description
	samplerDesc.AddressU = D3D11_TEXTURE_ADDRESS_CLAMP;
	samplerDesc.AddressV = D3D11_TEXTURE_ADDRESS_CLAMP;
	samplerDesc.AddressW = D3D11_TEXTURE_ADDRESS_CLAMP;

	renderer->CreateSamplerState(&samplerDesc, &clampSampState);
}

void PuzzleShader::initShader(WCHAR* vs, WCHAR* gs, WCHAR* ps)
{
	//overload initShader, loading the geometry shader then continuing as usual
	loadGeometryShader(gs);
	initShader(vs, ps);
}

void PuzzleShader::setShaderParameters(ID3D11DeviceContext* deviceContext, const XMMATRIX &world, const XMMATRIX &view, const XMMATRIX &projection, const XMFLOAT4 rotation, ID3D11ShaderResourceView* texture, XMFLOAT3 cameraPosition, Light* light, const XMMATRIX &lightProj, const XMMATRIX &lightView, ID3D11ShaderResourceView* shadowMap)
{
	HRESULT result;
	D3D11_MAPPED_SUBRESOURCE mappedResource;
	MatrixBufferType* dataPtr;
	RotationBufferType* rotatPtr;
	LightCameraBufferType* lightPtr;
	unsigned int bufferNumber;
	XMMATRIX tworld, tview, tproj, tlightProj, tlightView;

	// Transpose the matrices to prepare them for the shader.
	tworld = XMMatrixTranspose(world);
	tview = XMMatrixTranspose(view);
	tproj = XMMatrixTranspose(projection);

	// Lock the constant buffer so it can be written to.
	result = deviceContext->Map(matrixBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &mappedResource);

	// Get a pointer to the data in the constant buffer.
	dataPtr = (MatrixBufferType*)mappedResource.pData;

	// Copy the matrices into the constant buffer.
	dataPtr->world = tworld;
	dataPtr->view = tview;
	dataPtr->projection = tproj;

	// Unlock the constant buffer.
	deviceContext->Unmap(matrixBuffer, 0);

	// Set the position of the constant buffer in the vertex shader.
	bufferNumber = 0;

	// Now set the constant buffer in the vertex shader with the updated values.
	deviceContext->GSSetConstantBuffers(bufferNumber, 1, &matrixBuffer);

	//set up rotation buffer
	deviceContext->Map(rotationBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &mappedResource);
	rotatPtr = (RotationBufferType*)mappedResource.pData;
	rotatPtr->rotation = rotation;
	deviceContext->Unmap(rotationBuffer, 0);
	bufferNumber = 1;
	deviceContext->VSSetConstantBuffers(bufferNumber, 1, &rotationBuffer);

	//set up texture
	deviceContext->PSSetShaderResources(0, 1, &texture);

	tlightProj = XMMatrixTranspose(lightProj);
	tlightView = XMMatrixTranspose(lightView);

	//set up light and camera buffer
	deviceContext->Map(lightCameraBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &mappedResource);
	lightPtr = (LightCameraBufferType*)mappedResource.pData;
	lightPtr->cameraPosition = cameraPosition;
	lightPtr->lightAmbient = light->getAmbientColour();
	lightPtr->lightDiffuse = light->getDiffuseColour();
	lightPtr->lightPosition = light->getPosition();
	lightPtr->lightProjection = tlightProj;
	lightPtr->lightView = tlightView;
	lightPtr->lightSpecColour = light->getSpecularColour();
	lightPtr->lightSpecPower = light->getSpecularPower();
	deviceContext->Unmap(lightCameraBuffer, 0);
	bufferNumber = 2;
	deviceContext->PSSetConstantBuffers(bufferNumber, 1, &lightCameraBuffer);

	//set up shadow map texture
	deviceContext->PSSetShaderResources(1, 1, &shadowMap);

}

void PuzzleShader::render(ID3D11DeviceContext* deviceContext, int indexCount)
{
	// Set the sampler state in the pixel shader.
	deviceContext->PSSetSamplers(0, 1, &sampleState);

	deviceContext->PSSetSamplers(1, 1, &clampSampState);

	// Base render function.
	BaseShader::render(deviceContext, indexCount);
}