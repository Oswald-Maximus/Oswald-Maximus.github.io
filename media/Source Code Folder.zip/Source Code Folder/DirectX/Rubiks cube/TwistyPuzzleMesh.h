#ifndef _TWISTY_PUZZLE_MESH_H
#define _TWISTY_PUZZLE_MESH_H

#include "../DXFramework/BaseMesh.h"

using namespace DirectX;

class TwistyPuzzleMesh : public BaseMesh
{
public:
	TwistyPuzzleMesh(ID3D11Device* device, ID3D11DeviceContext* deviceContext);
	~TwistyPuzzleMesh();

	void sendData(ID3D11DeviceContext*);

protected:
	void initBuffers(ID3D11Device* device);
};
#endif